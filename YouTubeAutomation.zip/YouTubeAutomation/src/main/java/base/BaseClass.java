package base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import utils.ConfigReader;
import utils.WaitHelper;

/**
 * BaseClass
 * All test classes extend this class.
 * Handles browser launch, configuration, and teardown.
 * Uses WebDriverManager to automatically download and manage browser drivers.
 */
public class BaseClass {

    // WebDriver instance shared across all page classes via inheritance
    protected WebDriver driver;

    // WaitHelper instance for explicit waits
    protected WaitHelper waitHelper;

    /**
     * @BeforeClass runs once before any test method in the class.
     * Sets up the browser driver based on the config.properties value.
     */
    @BeforeClass
    public void setUp() {
        String browser = ConfigReader.getBrowser().toLowerCase();
        boolean headless = ConfigReader.isHeadless();

        System.out.println("[BaseClass] Launching browser: " + browser + " | Headless: " + headless);

        switch (browser) {
            case "chrome":
                // WebDriverManager downloads correct ChromeDriver automatically
                WebDriverManager.chromedriver().setup();
                ChromeOptions chromeOptions = new ChromeOptions();
                if (headless) {
                    chromeOptions.addArguments("--headless=new");  // Selenium 4 headless flag
                }
                chromeOptions.addArguments("--start-maximized");
                chromeOptions.addArguments("--disable-notifications");
                chromeOptions.addArguments("--disable-popup-blocking");
                chromeOptions.addArguments("--no-sandbox");
                chromeOptions.addArguments("--disable-dev-shm-usage");
                driver = new ChromeDriver(chromeOptions);
                break;

            case "firefox":
                // WebDriverManager downloads correct GeckoDriver automatically
                WebDriverManager.firefoxdriver().setup();
                FirefoxOptions firefoxOptions = new FirefoxOptions();
                if (headless) {
                    firefoxOptions.addArguments("-headless");
                }
                driver = new FirefoxDriver(firefoxOptions);
                driver.manage().window().maximize();
                break;

            default:
                throw new RuntimeException("[BaseClass] Unsupported browser in config: " + browser
                        + ". Use 'chrome' or 'firefox'.");
        }

        // Initialize WaitHelper with driver and configured timeout
        waitHelper = new WaitHelper(driver, ConfigReader.getTimeout());

        // Navigate to base URL
        driver.get(ConfigReader.getBaseUrl());
        System.out.println("[BaseClass] Navigated to: " + ConfigReader.getBaseUrl());
    }

    /**
     * @AfterClass runs once after all tests in the class complete.
     * Closes the browser and quits the driver session.
     */
    @AfterClass
    public void tearDown() {
        if (driver != null) {
            System.out.println("[BaseClass] Closing browser.");
            driver.quit();
        }
    }
}
