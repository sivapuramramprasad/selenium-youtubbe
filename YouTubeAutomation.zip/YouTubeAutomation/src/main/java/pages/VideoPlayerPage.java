package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.WaitHelper;

/**
 * VideoPlayerPage - Page Object for the YouTube video watch page.
 * Handles locators and interactions for the video player and related elements.
 */
public class VideoPlayerPage {

    private final WebDriver driver;
    private final WaitHelper waitHelper;

    // ─── Locators using @FindBy ─────────────────────────────────────────────

    /** The main HTML5 video player element */
    @FindBy(css = "video.html5-main-video")
    private WebElement videoPlayer;

    /** The video title displayed above the player */
    @FindBy(css = "h1.ytd-video-primary-info-renderer yt-formatted-string")
    private WebElement videoTitle;

    /** Play/Pause button inside the video player controls */
    @FindBy(css = ".ytp-play-button")
    private WebElement playPauseButton;

    /** Fullscreen button inside the video player controls */
    @FindBy(css = ".ytp-fullscreen-button")
    private WebElement fullscreenButton;

    /** Volume/Mute button inside the video player controls */
    @FindBy(css = ".ytp-mute-button")
    private WebElement muteButton;

    /** Progress bar / seek bar of the video */
    @FindBy(css = ".ytp-progress-bar")
    private WebElement progressBar;

    /** Like button under the video */
    @FindBy(css = "like-button-view-model button")
    private WebElement likeButton;

    // ─── Constructor ─────────────────────────────────────────────────────────

    public VideoPlayerPage(WebDriver driver, WaitHelper waitHelper) {
        this.driver = driver;
        this.waitHelper = waitHelper;
        PageFactory.initElements(driver, this);
    }

    // ─── Page Actions ────────────────────────────────────────────────────────

    /**
     * Waits for the video player element to be visible on the page.
     * Returns true if the player is displayed.
     */
    public boolean isVideoPlayerDisplayed() {
        try {
            waitHelper.waitForVisibility(By.cssSelector("video.html5-main-video"));
            return videoPlayer.isDisplayed();
        } catch (Exception e) {
            System.out.println("[VideoPlayerPage] Video player not found: " + e.getMessage());
            return false;
        }
    }

    /**
     * Returns the title text of the currently playing video.
     */
    public String getVideoTitle() {
        waitHelper.waitForVisibility(videoTitle);
        return videoTitle.getText();
    }

    /**
     * Returns the current page URL (should contain 'watch?v=')
     */
    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    /**
     * Checks whether the URL indicates we are on a video watch page
     */
    public boolean isOnVideoPage() {
        return waitHelper.waitForUrlContains("watch");
    }

    /**
     * Clicks the play/pause button on the video player
     */
    public void clickPlayPause() {
        waitHelper.waitForClickability(playPauseButton);
        playPauseButton.click();
        System.out.println("[VideoPlayerPage] Clicked Play/Pause button.");
    }

    /**
     * Clicks the mute/unmute button on the player
     */
    public void clickMute() {
        waitHelper.waitForClickability(muteButton);
        muteButton.click();
        System.out.println("[VideoPlayerPage] Clicked Mute button.");
    }

    /**
     * Checks if the progress bar (seek bar) is visible in the player controls
     */
    public boolean isProgressBarDisplayed() {
        try {
            waitHelper.waitForVisibility(progressBar);
            return progressBar.isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Returns the title of the browser tab/window (includes video name)
     */
    public String getPageTitle() {
        return driver.getTitle();
    }
}
