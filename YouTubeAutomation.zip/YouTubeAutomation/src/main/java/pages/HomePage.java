package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.WaitHelper;

import java.util.List;

/**
 * HomePage - Page Object for YouTube's main landing page.
 * Contains locators and actions for elements on the YouTube home page.
 * Uses PageFactory to initialize @FindBy annotated elements.
 */
public class HomePage {

    private final WebDriver driver;
    private final WaitHelper waitHelper;

    // ─── Locators using @FindBy ─────────────────────────────────────────────

    /** YouTube logo / home button in the top-left corner */
    @FindBy(id = "logo-icon")
    private WebElement youtubeLogo;

    /** Search input box in the header */
    @FindBy(name = "search_query")
    private WebElement searchBox;

    /** Search submit button (magnifying glass icon) */
    @FindBy(id = "search-icon-legacy")
    private WebElement searchButton;

    /** Search suggestions dropdown container */
    @FindBy(css = "ul[role='listbox'] li")
    private List<WebElement> searchSuggestions;

    /** Guide / hamburger menu button */
    @FindBy(id = "guide-button")
    private WebElement guideButton;

    // ─── Constructor ─────────────────────────────────────────────────────────

    /**
     * Constructor initializes all @FindBy elements via PageFactory
     *
     * @param driver     WebDriver instance from BaseClass
     * @param waitHelper WaitHelper instance for explicit waits
     */
    public HomePage(WebDriver driver, WaitHelper waitHelper) {
        this.driver = driver;
        this.waitHelper = waitHelper;
        // PageFactory links @FindBy annotated fields to actual DOM elements
        PageFactory.initElements(driver, this);
    }

    // ─── Page Actions ────────────────────────────────────────────────────────

    /**
     * Returns the current page title
     */
    public String getPageTitle() {
        return driver.getTitle();
    }

    /**
     * Checks if the YouTube logo is displayed on the page
     */
    public boolean isLogoDisplayed() {
        waitHelper.waitForVisibility(youtubeLogo);
        return youtubeLogo.isDisplayed();
    }

    /**
     * Clicks the YouTube logo to navigate back to home
     */
    public void clickYouTubeLogo() {
        waitHelper.waitForClickability(youtubeLogo);
        youtubeLogo.click();
        System.out.println("[HomePage] Clicked YouTube logo.");
    }

    /**
     * Returns the current URL from the browser
     */
    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    /**
     * Types a keyword into the search box (triggers suggestions dropdown)
     *
     * @param keyword text to type into the search box
     */
    public void typeInSearchBox(String keyword) {
        waitHelper.waitForVisibility(searchBox);
        searchBox.clear();
        searchBox.sendKeys(keyword);
        System.out.println("[HomePage] Typed search keyword: " + keyword);
    }

    /**
     * Types keyword and submits the search using the ENTER key
     *
     * @param keyword text to search
     */
    public SearchResultsPage searchFor(String keyword) {
        typeInSearchBox(keyword);
        searchBox.sendKeys(Keys.ENTER);
        System.out.println("[HomePage] Search submitted for: " + keyword);
        return new SearchResultsPage(driver, waitHelper);
    }

    /**
     * Clicks the search button after typing a keyword
     */
    public SearchResultsPage clickSearchButton() {
        waitHelper.waitForClickability(searchButton);
        searchButton.click();
        return new SearchResultsPage(driver, waitHelper);
    }

    /**
     * Returns the list of search suggestion elements shown in the dropdown.
     * YouTube shows suggestions after typing a few characters.
     *
     * @return list of suggestion WebElements
     */
    public List<WebElement> getSearchSuggestions() {
        // Wait for at least one suggestion to appear in the DOM
        waitHelper.waitForPresenceOfAll(By.cssSelector("ul[role='listbox'] li"));
        return searchSuggestions;
    }

    /**
     * Checks if the search suggestions list is non-empty
     */
    public boolean areSuggestionsVisible() {
        try {
            List<WebElement> suggestions = getSearchSuggestions();
            return suggestions != null && !suggestions.isEmpty();
        } catch (Exception e) {
            System.out.println("[HomePage] No suggestions found: " + e.getMessage());
            return false;
        }
    }
}
