package utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * ConfigReader utility class
 * Reads all test configuration from config/config.properties
 * Follows Singleton pattern to avoid re-loading the file on every call.
 */
public class ConfigReader {

    private static Properties properties;
    private static final String CONFIG_PATH = "config/config.properties";

    // Static block loads the properties file once when class is first accessed
    static {
        try {
            FileInputStream fis = new FileInputStream(CONFIG_PATH);
            properties = new Properties();
            properties.load(fis);
            fis.close();
            System.out.println("[ConfigReader] Loaded config from: " + CONFIG_PATH);
        } catch (IOException e) {
            throw new RuntimeException("[ConfigReader] Failed to load config.properties from path: "
                    + CONFIG_PATH, e);
        }
    }

    // Private constructor prevents instantiation
    private ConfigReader() {}

    /**
     * Returns the browser name (chrome / firefox)
     */
    public static String getBrowser() {
        return getProperty("browser");
    }

    /**
     * Returns the base URL of the application
     */
    public static String getBaseUrl() {
        return getProperty("baseUrl");
    }

    /**
     * Returns the explicit wait timeout in seconds
     */
    public static int getTimeout() {
        return Integer.parseInt(getProperty("timeout"));
    }

    /**
     * Returns the search keyword to use in search tests
     */
    public static String getSearchKeyword() {
        return getProperty("searchKeyword");
    }

    /**
     * Returns whether to run browser in headless mode
     */
    public static boolean isHeadless() {
        return Boolean.parseBoolean(getProperty("headless"));
    }

    /**
     * Generic method to fetch any property value by key
     * Throws RuntimeException if key is missing
     */
    public static String getProperty(String key) {
        String value = properties.getProperty(key);
        if (value == null || value.trim().isEmpty()) {
            throw new RuntimeException("[ConfigReader] Property '" + key + "' not found in config.properties");
        }
        return value.trim();
    }
}
