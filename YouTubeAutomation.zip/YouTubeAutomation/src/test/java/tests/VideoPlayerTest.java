package tests;

import base.BaseClass;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.SearchResultsPage;
import pages.VideoPlayerPage;
import utils.ConfigReader;

/**
 * VideoPlayerTest
 * Test cases for the YouTube video player page:
 *   1. Verify clicking a video result opens the video player
 *   2. Verify the player URL contains 'watch?v='
 *   3. Verify the progress bar is visible in the player
 *
 * Extends BaseClass to inherit WebDriver setup and teardown.
 */
public class VideoPlayerTest extends BaseClass {

    private HomePage homePage;
    private SearchResultsPage searchResultsPage;
    private VideoPlayerPage videoPlayerPage;

    /**
     * Setup: launch browser and navigate to YouTube, then search for a video
     * so that we can click on a result in the test methods.
     */
    @BeforeClass
    @Override
    public void setUp() {
        super.setUp();

        // Initialize page objects
        homePage = new HomePage(driver, waitHelper);

        // Perform a search to get to the results page (shared state for tests below)
        String keyword = ConfigReader.getSearchKeyword();
        System.out.println("[VideoPlayerTest] Searching for: " + keyword);
        searchResultsPage = homePage.searchFor(keyword);
    }

    // ─── Test Cases ──────────────────────────────────────────────────────────

    /**
     * TC-07: Click the first video in results and verify the player page opens.
     * Checks that the URL transitions to a 'watch' URL.
     */
    @Test(priority = 1,
          groups = {"smoke", "video"},
          description = "Verify clicking a video result navigates to the video player page")
    public void verifyVideoPlayerOpens() {
        // Click the first search result video
        videoPlayerPage = searchResultsPage.clickFirstVideo();

        // Wait for and verify the URL transitions to a watch page
        boolean onVideoPage = videoPlayerPage.isOnVideoPage();
        String url = videoPlayerPage.getCurrentUrl();
        System.out.println("[VideoPlayerTest] Current URL after click: " + url);

        Assert.assertTrue(onVideoPage,
                "After clicking a video, URL should contain 'watch'. Actual URL: " + url);
    }

    /**
     * TC-08: Verify that the HTML5 video player element is present and visible.
     */
    @Test(priority = 2,
          groups = {"smoke", "video"},
          description = "Verify the video player element is displayed on the watch page",
          dependsOnMethods = {"verifyVideoPlayerOpens"})
    public void verifyVideoPlayerIsDisplayed() {
        boolean playerDisplayed = videoPlayerPage.isVideoPlayerDisplayed();
        System.out.println("[VideoPlayerTest] Video player displayed: " + playerDisplayed);
        Assert.assertTrue(playerDisplayed,
                "The HTML5 video player element should be visible on the video page.");
    }

    /**
     * TC-09: Verify the page title on the video watch page is not empty.
     * A valid video page should have a descriptive title in the browser tab.
     */
    @Test(priority = 3,
          groups = {"regression", "video"},
          description = "Verify the video page has a non-empty browser tab title",
          dependsOnMethods = {"verifyVideoPlayerOpens"})
    public void verifyVideoPageTitleIsNotEmpty() {
        String pageTitle = videoPlayerPage.getPageTitle();
        System.out.println("[VideoPlayerTest] Video page title: " + pageTitle);
        Assert.assertNotNull(pageTitle, "Page title should not be null.");
        Assert.assertFalse(pageTitle.isEmpty(), "Page title should not be empty on video page.");
    }

    /**
     * TC-10: Verify the video progress bar (seek bar) is visible in the player controls.
     */
    @Test(priority = 4,
          groups = {"regression", "video"},
          description = "Verify the video progress/seek bar is displayed",
          dependsOnMethods = {"verifyVideoPlayerOpens"})
    public void verifyProgressBarIsDisplayed() {
        boolean progressBarVisible = videoPlayerPage.isProgressBarDisplayed();
        System.out.println("[VideoPlayerTest] Progress bar visible: " + progressBarVisible);
        Assert.assertTrue(progressBarVisible,
                "The video progress/seek bar should be visible on the video player page.");
    }
}
