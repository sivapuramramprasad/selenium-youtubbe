package tests;

import base.BaseClass;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.SearchResultsPage;
import utils.ConfigReader;

/**
 * SearchTest
 * Test cases for YouTube search functionality:
 *   1. Verify search results appear after searching a keyword
 *   2. Verify search suggestions dropdown appears while typing
 *   3. Verify URL updates correctly after a search
 *
 * Extends BaseClass to inherit WebDriver setup and teardown.
 */
public class SearchTest extends BaseClass {

    private HomePage homePage;
    private SearchResultsPage searchResultsPage;

    /**
     * Setup: launch browser (via super) then initialize page objects
     */
    @BeforeClass
    @Override
    public void setUp() {
        super.setUp();
        homePage = new HomePage(driver, waitHelper);
        System.out.println("[SearchTest] HomePage initialized.");
    }

    // ─── Test Cases ──────────────────────────────────────────────────────────

    /**
     * TC-04: Type a keyword in the search box and verify suggestions appear.
     * YouTube auto-suggests results after a few characters are typed.
     */
    @Test(priority = 1,
          groups = {"smoke", "search"},
          description = "Verify search suggestions appear when typing in search box")
    public void verifySearchSuggestionsAppear() {
        // Navigate to YouTube home before the test
        driver.get(ConfigReader.getBaseUrl());

        // Type part of the search keyword (triggers suggestion dropdown)
        homePage.typeInSearchBox("Selenium");

        // Check that the suggestions dropdown has items
        boolean suggestionsVisible = homePage.areSuggestionsVisible();
        System.out.println("[SearchTest] Suggestions visible: " + suggestionsVisible);
        Assert.assertTrue(suggestionsVisible,
                "Search suggestions should appear after typing 'Selenium'");
    }

    /**
     * TC-05: Perform a full search and verify results are displayed.
     */
    @Test(priority = 2,
          groups = {"smoke", "search"},
          description = "Verify search results appear for a given keyword",
          dependsOnMethods = {"verifySearchSuggestionsAppear"})
    public void verifySearchResultsAppear() {
        // Navigate to home and perform a search
        driver.get(ConfigReader.getBaseUrl());
        String keyword = ConfigReader.getSearchKeyword();

        searchResultsPage = homePage.searchFor(keyword);

        // Verify we are on the results page
        boolean onResultsPage = searchResultsPage.isOnSearchResultsPage();
        Assert.assertTrue(onResultsPage, "Should navigate to search results page after search.");

        // Verify results are displayed
        boolean resultsDisplayed = searchResultsPage.areResultsDisplayed();
        System.out.println("[SearchTest] Results displayed: " + resultsDisplayed
                + " | Count: " + searchResultsPage.getResultCount());
        Assert.assertTrue(resultsDisplayed,
                "Search results should be displayed for keyword: " + keyword);
    }

    /**
     * TC-06: Verify the search results page URL contains the search query.
     */
    @Test(priority = 3,
          groups = {"regression", "search"},
          description = "Verify URL contains search query after searching",
          dependsOnMethods = {"verifySearchResultsAppear"})
    public void verifySearchUrlContainsKeyword() {
        // searchResultsPage is already set from the previous test
        String currentUrl = searchResultsPage.getCurrentUrl();
        System.out.println("[SearchTest] Search results URL: " + currentUrl);

        Assert.assertTrue(currentUrl.contains("results"),
                "URL should contain 'results' on the search results page. Actual: " + currentUrl);
        Assert.assertTrue(currentUrl.contains("search_query"),
                "URL should contain 'search_query' parameter. Actual: " + currentUrl);
    }
}
