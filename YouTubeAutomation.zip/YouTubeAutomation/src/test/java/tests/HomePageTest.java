package tests;

import base.BaseClass;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.HomePage;
import utils.ConfigReader;

/**
 * HomePageTest
 * Test cases covering the YouTube homepage:
 *   1. Verify page title contains "YouTube"
 *   2. Verify YouTube logo is displayed
 *   3. Verify logo click redirects to home page URL
 *
 * Extends BaseClass to inherit driver setup/teardown.
 */
public class HomePageTest extends BaseClass {

    private HomePage homePage;

    /**
     * Initializes the HomePage object before tests run.
     * @BeforeClass here runs AFTER BaseClass.setUp() because
     * TestNG processes parent @BeforeClass first.
     */
    @BeforeClass
    @Override
    public void setUp() {
        super.setUp(); // Launch browser and navigate to base URL
        homePage = new HomePage(driver, waitHelper);
        System.out.println("[HomePageTest] HomePage initialized.");
    }

    // ─── Test Cases ──────────────────────────────────────────────────────────

    /**
     * TC-01: Verify that the YouTube homepage title contains "YouTube"
     * Priority 1 = runs first in this class
     */
    @Test(priority = 1,
          groups = {"smoke", "homepage"},
          description = "Verify YouTube homepage title contains 'YouTube'")
    public void verifyPageTitleContainsYouTube() {
        String title = homePage.getPageTitle();
        System.out.println("[HomePageTest] Page title: " + title);
        Assert.assertTrue(title.contains("YouTube"),
                "Page title should contain 'YouTube' but was: " + title);
    }

    /**
     * TC-02: Verify the YouTube logo/icon is displayed on the homepage
     */
    @Test(priority = 2,
          groups = {"smoke", "homepage"},
          description = "Verify YouTube logo is visible on homepage")
    public void verifyYouTubeLogoIsDisplayed() {
        boolean isDisplayed = homePage.isLogoDisplayed();
        System.out.println("[HomePageTest] Logo displayed: " + isDisplayed);
        Assert.assertTrue(isDisplayed, "YouTube logo should be visible on the homepage.");
    }

    /**
     * TC-03: Verify that clicking the YouTube logo redirects to the home page.
     * Navigates away and then clicks logo to return.
     */
    @Test(priority = 3,
          groups = {"regression", "homepage"},
          description = "Verify YouTube logo click redirects to homepage URL")
    public void verifyLogoClickRedirectsToHome() {
        // First navigate to search to simulate being on another page
        driver.navigate().to(ConfigReader.getBaseUrl() + "results?search_query=test");

        // Wait for page to load, then click logo
        homePage.clickYouTubeLogo();

        // Verify URL is back to the YouTube home
        String currentUrl = homePage.getCurrentUrl();
        System.out.println("[HomePageTest] URL after logo click: " + currentUrl);
        Assert.assertTrue(currentUrl.contains("youtube.com"),
                "After clicking logo, URL should contain 'youtube.com' but was: " + currentUrl);
    }
}
