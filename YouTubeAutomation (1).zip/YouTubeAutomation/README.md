# 🎬 YouTube Selenium Automation Framework

A production-ready, end-to-end Selenium 4 + TestNG automation framework for [YouTube](https://www.youtube.com/), built using the **Page Object Model (POM)** design pattern with Maven.

---

## 📁 Project Structure

```
YouTubeAutomation/
├── src/
│   ├── main/java/
│   │   ├── base/
│   │   │   └── BaseClass.java          # Browser setup/teardown
│   │   ├── pages/
│   │   │   ├── HomePage.java           # YouTube home page actions
│   │   │   ├── SearchResultsPage.java  # Search results actions
│   │   │   └── VideoPlayerPage.java    # Video watch page actions
│   │   └── utils/
│   │       ├── ConfigReader.java       # Reads config.properties
│   │       └── WaitHelper.java         # Explicit wait utilities
│   └── test/java/
│       └── tests/
│           ├── HomePageTest.java       # Homepage test cases
│           ├── SearchTest.java         # Search test cases
│           └── VideoPlayerTest.java    # Video player test cases
├── config/
│   └── config.properties              # All test config (browser, URL, timeout)
├── testng.xml                         # TestNG suite config (parallel execution)
├── pom.xml                            # Maven build & dependency config
└── README.md
```

---

## ✅ Prerequisites

| Tool        | Version  |
|-------------|----------|
| Java JDK    | 11+      |
| Maven       | 3.8+     |
| Chrome      | Latest   |
| Firefox     | Latest (optional) |
| IDE         | IntelliJ IDEA or Eclipse |

> **No manual ChromeDriver/GeckoDriver download needed!** WebDriverManager handles it automatically.

---

## ⚙️ Configuration

Edit `config/config.properties` to customize:

```properties
browser=chrome          # chrome | firefox
baseUrl=https://www.youtube.com/
timeout=15              # Explicit wait timeout in seconds
searchKeyword=Selenium Java tutorial
headless=false          # true for CI/CD pipelines
```

---

## 🚀 How to Run

### Option 1: Maven Command Line
```bash
# Run all tests
mvn clean test

# Run only smoke tests
mvn clean test -Dgroups=smoke

# Run only regression tests
mvn clean test -Dgroups=regression

# Run in headless mode (override config)
mvn clean test -Dheadless=true
```

### Option 2: From IDE
1. Import as a Maven project (File → Open → select folder)
2. Right-click `testng.xml` → **Run As > TestNG Suite**
3. Or right-click any test class → **Run As > TestNG Test**

---

## 🧪 Test Cases

| # | Test Class | Test Method | Group | Description |
|---|------------|-------------|-------|-------------|
| TC-01 | HomePageTest | `verifyPageTitleContainsYouTube` | smoke | Page title contains "YouTube" |
| TC-02 | HomePageTest | `verifyYouTubeLogoIsDisplayed` | smoke | Logo is visible |
| TC-03 | HomePageTest | `verifyLogoClickRedirectsToHome` | regression | Logo click goes to home |
| TC-04 | SearchTest | `verifySearchSuggestionsAppear` | smoke | Suggestions show while typing |
| TC-05 | SearchTest | `verifySearchResultsAppear` | smoke | Results load after search |
| TC-06 | SearchTest | `verifySearchUrlContainsKeyword` | regression | URL has search query param |
| TC-07 | VideoPlayerTest | `verifyVideoPlayerOpens` | smoke | Clicking video opens player |
| TC-08 | VideoPlayerTest | `verifyVideoPlayerIsDisplayed` | smoke | Video element is visible |
| TC-09 | VideoPlayerTest | `verifyVideoPageTitleIsNotEmpty` | regression | Tab title is set |
| TC-10 | VideoPlayerTest | `verifyProgressBarIsDisplayed` | regression | Seek bar is visible |

---

## 🏗️ Architecture

```
BaseClass (browser setup/teardown)
    │
    ├── HomePageTest ──► HomePage ──────────────► SearchResultsPage
    ├── SearchTest ────► HomePage ──► SearchResultsPage ──► VideoPlayerPage
    └── VideoPlayerTest► HomePage ──► SearchResultsPage ──► VideoPlayerPage
                                              │
                                       WaitHelper (explicit waits)
                                       ConfigReader (config.properties)
```

- **No Thread.sleep** anywhere — all waits use `WebDriverWait` + `ExpectedConditions`
- **Parallel execution** — 3 test classes run simultaneously in separate threads/browsers
- **PageFactory** — all page element locators initialized via `@FindBy` + `PageFactory.initElements()`

---

## 📊 Reports

After running, TestNG generates reports at:
```
target/surefire-reports/index.html   # Maven Surefire report
test-output/index.html               # TestNG default report
```

Open `test-output/index.html` in a browser for a detailed test run breakdown.

---

## 🔧 Troubleshooting

| Issue | Solution |
|-------|----------|
| `ChromeDriver not found` | WebDriverManager should auto-download; ensure internet access |
| `Element not found` | Increase `timeout` in `config.properties` |
| Tests fail on CI/CD | Set `headless=true` in config |
| Firefox not working | Install Firefox browser, change `browser=firefox` |
