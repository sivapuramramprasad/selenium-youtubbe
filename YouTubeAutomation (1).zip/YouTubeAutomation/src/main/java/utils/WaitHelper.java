package utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

/**
 * WaitHelper utility class
 * Provides reusable explicit wait methods throughout the framework.
 * No Thread.sleep is used anywhere — all waits are condition-based.
 */
public class WaitHelper {

    private final WebDriverWait wait;

    /**
     * Constructor accepts the driver and timeout from config
     *
     * @param driver  WebDriver instance
     * @param timeout Timeout in seconds (read from ConfigReader)
     */
    public WaitHelper(WebDriver driver, int timeout) {
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
    }

    /**
     * Waits until the given element is visible in the DOM and on screen
     *
     * @param element WebElement to wait for
     * @return the element once visible
     */
    public WebElement waitForVisibility(WebElement element) {
        return wait.until(ExpectedConditions.visibilityOf(element));
    }

    /**
     * Waits until an element located by the given By locator is visible
     *
     * @param locator By locator
     * @return visible WebElement
     */
    public WebElement waitForVisibility(By locator) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    /**
     * Waits until the given element is clickable (visible + enabled)
     *
     * @param element WebElement to wait for
     * @return the element once clickable
     */
    public WebElement waitForClickability(WebElement element) {
        return wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    /**
     * Waits until the page title contains the expected substring
     *
     * @param titleSubstring substring expected in title
     * @return true once the title contains the substring
     */
    public boolean waitForTitleContains(String titleSubstring) {
        return wait.until(ExpectedConditions.titleContains(titleSubstring));
    }

    /**
     * Waits until at least one element from a list is visible
     *
     * @param locator By locator
     * @return list of visible elements
     */
    public List<WebElement> waitForPresenceOfAll(By locator) {
        return wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(locator));
    }

    /**
     * Waits until the URL contains a specific substring
     *
     * @param urlFragment expected URL fragment
     * @return true once URL contains the fragment
     */
    public boolean waitForUrlContains(String urlFragment) {
        return wait.until(ExpectedConditions.urlContains(urlFragment));
    }
}
