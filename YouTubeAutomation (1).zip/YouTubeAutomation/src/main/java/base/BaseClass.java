package base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import utils.ConfigReader;
import utils.WaitHelper;

/**
 * BaseClass
 * All test classes extend this class.
 * Provides shared browser initialization and teardown logic.
 * Each subclass calls initDriver() in its own @BeforeClass to avoid
 * parallel execution issues with TestNG lifecycle ordering.
 */
public class BaseClass {

    // WebDriver instance - each test class gets its own via parallel threads
    protected WebDriver driver;

    // WaitHelper instance for explicit waits
    protected WaitHelper waitHelper;

    /**
     * Initializes the WebDriver based on config.properties browser setting.
     * Called explicitly by each subclass @BeforeClass method.
     * This avoids TestNG parallel class issues with inherited @BeforeClass.
     */
    protected void initDriver() {
        String browser = ConfigReader.getBrowser().toLowerCase();
        boolean headless = ConfigReader.isHeadless();

        System.out.println("[BaseClass] Launching browser: " + browser + " | Headless: " + headless);

        switch (browser) {
            case "chrome":
                WebDriverManager.chromedriver().setup();
                ChromeOptions chromeOptions = new ChromeOptions();
                if (headless) {
                    chromeOptions.addArguments("--headless=new");
                }
                chromeOptions.addArguments("--window-size=1920,1080");
                chromeOptions.addArguments("--disable-notifications");
                chromeOptions.addArguments("--disable-popup-blocking");
                chromeOptions.addArguments("--no-sandbox");
                chromeOptions.addArguments("--disable-dev-shm-usage");
                chromeOptions.addArguments("--disable-gpu");
                chromeOptions.addArguments("--remote-allow-origins=*");
                driver = new ChromeDriver(chromeOptions);
                break;

            case "firefox":
                WebDriverManager.firefoxdriver().setup();
                FirefoxOptions firefoxOptions = new FirefoxOptions();
                if (headless) {
                    firefoxOptions.addArguments("-headless");
                }
                driver = new FirefoxDriver(firefoxOptions);
                driver.manage().window().maximize();
                break;

            default:
                throw new RuntimeException("[BaseClass] Unsupported browser: " + browser
                        + ". Use 'chrome' or 'firefox'.");
        }

        // Initialize WaitHelper with driver and timeout from config
        waitHelper = new WaitHelper(driver, ConfigReader.getTimeout());

        // Navigate to base URL
        driver.get(ConfigReader.getBaseUrl());
        System.out.println("[BaseClass] Navigated to: " + ConfigReader.getBaseUrl());
    }

    /**
     * Quits the browser. Called by each subclass @AfterClass method.
     */
    protected void quitDriver() {
        if (driver != null) {
            System.out.println("[BaseClass] Closing browser.");
            driver.quit();
            driver = null;
        }
    }
}
