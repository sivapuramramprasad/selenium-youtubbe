package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.WaitHelper;

import java.util.List;

/**
 * SearchResultsPage - Page Object for YouTube Search Results page.
 * Handles locators and actions for search result elements.
 */
public class SearchResultsPage {

    private final WebDriver driver;
    private final WaitHelper waitHelper;

    // ─── Locators using @FindBy ─────────────────────────────────────────────

    /** All video result items shown in the search results list */
    @FindBy(css = "ytd-video-renderer")
    private List<WebElement> videoResults;

    /** Title link of each video result - used to click on first result */
    @FindBy(css = "ytd-video-renderer #video-title")
    private List<WebElement> videoTitles;

    /** The search query text box (still present on results page) */
    @FindBy(name = "search_query")
    private WebElement searchBox;

    /** Filter/sort options container */
    @FindBy(id = "filter-menu")
    private WebElement filterMenu;

    // ─── Constructor ─────────────────────────────────────────────────────────

    public SearchResultsPage(WebDriver driver, WaitHelper waitHelper) {
        this.driver = driver;
        this.waitHelper = waitHelper;
        PageFactory.initElements(driver, this);
    }

    // ─── Page Actions ────────────────────────────────────────────────────────

    /**
     * Waits for and returns all video result elements.
     * Uses explicit wait for at least one result to appear.
     */
    public List<WebElement> getVideoResults() {
        waitHelper.waitForPresenceOfAll(By.cssSelector("ytd-video-renderer"));
        return videoResults;
    }

    /**
     * Returns the number of video results displayed
     */
    public int getResultCount() {
        return getVideoResults().size();
    }

    /**
     * Checks if search results are displayed (at least 1 result)
     */
    public boolean areResultsDisplayed() {
        try {
            return getResultCount() > 0;
        } catch (Exception e) {
            System.out.println("[SearchResultsPage] No results found: " + e.getMessage());
            return false;
        }
    }

    /**
     * Returns the title text of the first video result
     */
    public String getFirstVideoTitle() {
        waitHelper.waitForPresenceOfAll(By.cssSelector("ytd-video-renderer #video-title"));
        return videoTitles.get(0).getText();
    }

    /**
     * Clicks on the first video in the search results.
     * Returns a VideoPlayerPage to continue interaction.
     */
    public VideoPlayerPage clickFirstVideo() {
        waitHelper.waitForPresenceOfAll(By.cssSelector("ytd-video-renderer #video-title"));
        WebElement firstTitle = videoTitles.get(0);
        waitHelper.waitForClickability(firstTitle);
        System.out.println("[SearchResultsPage] Clicking first video: " + firstTitle.getText());
        firstTitle.click();
        return new VideoPlayerPage(driver, waitHelper);
    }

    /**
     * Returns the current page URL (should contain 'results?search_query=')
     */
    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    /**
     * Returns true if the URL is the search results URL
     */
    public boolean isOnSearchResultsPage() {
        return waitHelper.waitForUrlContains("results");
    }
}
