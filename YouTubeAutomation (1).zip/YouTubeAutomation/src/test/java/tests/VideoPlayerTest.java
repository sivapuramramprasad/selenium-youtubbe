package tests;

import base.BaseClass;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.SearchResultsPage;
import pages.VideoPlayerPage;
import utils.ConfigReader;

/**
 * VideoPlayerTest
 * Test cases for the YouTube video player page:
 *   1. Verify clicking a video result opens the video player
 *   2. Verify the player element is visible
 *   3. Verify the page title is not empty
 *   4. Verify the progress bar is visible
 */
public class VideoPlayerTest extends BaseClass {

    private HomePage homePage;
    private SearchResultsPage searchResultsPage;
    private VideoPlayerPage videoPlayerPage;

    /**
     * Launches browser, searches for a video, so tests can click results.
     */
    @BeforeClass
    public void setUp() {
        initDriver(); // explicitly call BaseClass method
        homePage = new HomePage(driver, waitHelper);

        // Search so results page is ready for tests
        String keyword = ConfigReader.getSearchKeyword();
        System.out.println("[VideoPlayerTest] Searching for: " + keyword);
        searchResultsPage = homePage.searchFor(keyword);
        System.out.println("[VideoPlayerTest] setUp complete.");
    }

    @AfterClass
    public void tearDown() {
        quitDriver();
    }

    // ─── Test Cases ──────────────────────────────────────────────────────────

    /**
     * TC-07: Click the first video in results and verify the player page opens
     */
    @Test(priority = 1,
          groups = {"smoke", "video"},
          description = "Verify clicking a video result navigates to the video player page")
    public void verifyVideoPlayerOpens() {
        videoPlayerPage = searchResultsPage.clickFirstVideo();

        boolean onVideoPage = videoPlayerPage.isOnVideoPage();
        String url = videoPlayerPage.getCurrentUrl();
        System.out.println("[VideoPlayerTest] URL after click: " + url);

        Assert.assertTrue(onVideoPage,
                "After clicking a video, URL should contain 'watch'. Actual: " + url);
    }

    /**
     * TC-08: Verify the HTML5 video player element is present and visible
     */
    @Test(priority = 2,
          groups = {"smoke", "video"},
          description = "Verify the video player element is displayed",
          dependsOnMethods = {"verifyVideoPlayerOpens"})
    public void verifyVideoPlayerIsDisplayed() {
        boolean playerDisplayed = videoPlayerPage.isVideoPlayerDisplayed();
        System.out.println("[VideoPlayerTest] Video player displayed: " + playerDisplayed);
        Assert.assertTrue(playerDisplayed,
                "The HTML5 video player element should be visible on the video page.");
    }

    /**
     * TC-09: Verify the browser tab title is not empty on the video page
     */
    @Test(priority = 3,
          groups = {"regression", "video"},
          description = "Verify the video page has a non-empty browser tab title",
          dependsOnMethods = {"verifyVideoPlayerOpens"})
    public void verifyVideoPageTitleIsNotEmpty() {
        String pageTitle = videoPlayerPage.getPageTitle();
        System.out.println("[VideoPlayerTest] Video page title: " + pageTitle);
        Assert.assertNotNull(pageTitle, "Page title should not be null.");
        Assert.assertFalse(pageTitle.isEmpty(), "Page title should not be empty.");
    }

    /**
     * TC-10: Verify the video progress bar is visible in the player controls
     */
    @Test(priority = 4,
          groups = {"regression", "video"},
          description = "Verify the video progress/seek bar is displayed",
          dependsOnMethods = {"verifyVideoPlayerOpens"})
    public void verifyProgressBarIsDisplayed() {
        boolean progressBarVisible = videoPlayerPage.isProgressBarDisplayed();
        System.out.println("[VideoPlayerTest] Progress bar visible: " + progressBarVisible);
        Assert.assertTrue(progressBarVisible,
                "The video progress bar should be visible on the player page.");
    }
}
