package tests;

import base.BaseClass;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.SearchResultsPage;
import utils.ConfigReader;

/**
 * SearchTest
 * Test cases for YouTube search functionality:
 *   1. Verify search suggestions appear while typing
 *   2. Verify search results appear after searching
 *   3. Verify URL updates correctly after a search
 */
public class SearchTest extends BaseClass {

    private HomePage homePage;
    private SearchResultsPage searchResultsPage;

    /**
     * Launches browser and navigates to YouTube before tests run.
     */
    @BeforeClass
    public void setUp() {
        initDriver(); // explicitly call BaseClass method
        homePage = new HomePage(driver, waitHelper);
        System.out.println("[SearchTest] setUp complete.");
    }

    @AfterClass
    public void tearDown() {
        quitDriver();
    }

    // ─── Test Cases ──────────────────────────────────────────────────────────

    /**
     * TC-04: Type a keyword and verify search suggestions appear
     */
    @Test(priority = 1,
          groups = {"smoke", "search"},
          description = "Verify search suggestions appear when typing in search box")
    public void verifySearchSuggestionsAppear() {
        driver.get(ConfigReader.getBaseUrl());
        homePage.typeInSearchBox("Selenium");

        boolean suggestionsVisible = homePage.areSuggestionsVisible();
        System.out.println("[SearchTest] Suggestions visible: " + suggestionsVisible);
        Assert.assertTrue(suggestionsVisible,
                "Search suggestions should appear after typing 'Selenium'");
    }

    /**
     * TC-05: Perform a full search and verify results are displayed
     */
    @Test(priority = 2,
          groups = {"smoke", "search"},
          description = "Verify search results appear for a given keyword")
    public void verifySearchResultsAppear() {
        driver.get(ConfigReader.getBaseUrl());
        String keyword = ConfigReader.getSearchKeyword();

        searchResultsPage = homePage.searchFor(keyword);

        boolean onResultsPage = searchResultsPage.isOnSearchResultsPage();
        Assert.assertTrue(onResultsPage, "Should navigate to search results page after search.");

        boolean resultsDisplayed = searchResultsPage.areResultsDisplayed();
        System.out.println("[SearchTest] Results displayed: " + resultsDisplayed
                + " | Count: " + searchResultsPage.getResultCount());
        Assert.assertTrue(resultsDisplayed,
                "Search results should be displayed for keyword: " + keyword);
    }

    /**
     * TC-06: Verify the search results URL contains the search query param
     */
    @Test(priority = 3,
          groups = {"regression", "search"},
          description = "Verify URL contains search query after searching",
          dependsOnMethods = {"verifySearchResultsAppear"})
    public void verifySearchUrlContainsKeyword() {
        String currentUrl = searchResultsPage.getCurrentUrl();
        System.out.println("[SearchTest] Search results URL: " + currentUrl);

        Assert.assertTrue(currentUrl.contains("results"),
                "URL should contain 'results'. Actual: " + currentUrl);
        Assert.assertTrue(currentUrl.contains("search_query"),
                "URL should contain 'search_query'. Actual: " + currentUrl);
    }
}
